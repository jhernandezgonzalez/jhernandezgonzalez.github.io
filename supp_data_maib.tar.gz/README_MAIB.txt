README MAIB DATA

Python script that returns the dataset in a numpy array.

Call real_data_MAIB()

It returns a Python dictionary with the following fields:
- J:  number of students
- G:  number of peer-assessed grades per activity
- N:  total number of peer-assessed grades
- z:  N-length array with the peer-assessed grades
 + ss: N-length array with the indices of the graded test
 + gg: N-length array with the indices of the grader
- s:  J-length array with the teacher's grades


Call real_data_MAIB(True)
And it returns, additionally, per-question (3) information with the following fields:
- z_pp: (Nx3)-matrix where each row gives the grades peer-assessed per question
- s_pp: (Jx3)-matrix where each row gives the teacher's grades per question