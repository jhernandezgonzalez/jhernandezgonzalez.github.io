README MPD DATA

Python script that returns the dataset in a numpy array.

Call real_data_MPD()

It returns a Python dictionary with the following fields:
- J:  number of students
- G:  number of peer-assessed grades per activity
- N:  total number of peer-assessed grades
- z:  N-length array with the peer-assessed grades
 + ss: N-length array with the indices of the graded test
 + gg: N-length array with the indices of the grader
- s:  J-length array with the teacher's grades
