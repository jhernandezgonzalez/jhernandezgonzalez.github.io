import numpy as np


def real_data_MPD():
    J = 16    # no. students
    G = 15    # no. peer-assessed grades per activity
    N = J * G # no. total grades

    # indices of the graded test
    ss = np.repeat(np.arange(J, dtype=int), J)

    # indices of the grader
    gg = np.tile(np.arange(J, dtype=int), J)

    # peer-assessed grades
    z = np.array(
        [-1, 10, 9, 7, 10, 10, 10, 9, 7, 9, 9, 9, 10, 8, 9, 9, 6, -1, 4, 5, 7, 6, 6, 7, 6, 7, 6, 7, 5, 7, 6, 7, 7, 8,
         -1, 6, 7, 9, 8, 6, 7, 8, 8, 8, 7, 7, 6, 7, 8, 8, 8, -1, 9, 10, 10, 10, 7, 9, 8, 9, 10, 7, 10, 9, 7, 7, 8, 5,
         -1, 10, 7, 6, 6, 8, 6, 7, 6, 7, 8, 7, 7, 8, 7, 7, 8, -1, 9, 8, 6, 8, 7, 9, 7, 7, 9, 8, 7, 9, 8, 7, 7, 10, -1,
         5, 5, 8, 8, 7, 7, 8, 10, 9, 6, 9, 10, 9, 8, 10, 10, -1, 9, 10, 9, 8, 9, 9, 10, 9, 4, 8, 6, 5, 6, 9, 4, 5, -1,
         8, 5, 7, 8, 6, 6, 8, 6, 7, 5, 4, 8, 10, 5, 6, 6, -1, 7, 7, 6, 7, 7, 8, 7, 6, 5, 4, 6, 10, 6, 7, 5, 8, -1, 6, 6,
         7, 7, 7, 7, 8, 7, 6, 7, 10, 6, 8, 7, 9, 9, -1, 7, 7, 7, 8, 7, 7, 8, 6, 8, 9, 8, 8, 8, 8, 8, 8, -1, 8, 7, 9, 6,
         8, 8, 8, 8, 9, 9, 9, 7, 8, 8, 7, 9, -1, 7, 8, 8, 9, 9, 7, 9, 10, 10, 10, 8, 10, 7, 8, 7, 8, -1, 9, 4, 8, 5, 4,
         7, 8, 5, 6, 6, 8, 7, 8, 5, 8, 6, -1])

    # teacher's grades
    s = np.array([9,5,7,7,6,7,8,9,5,5,6,7,7,8,9,6])

    # We don't keep entries where i=j (self assigned grade, not available, -1)
    tokeep = z!=-1
    z = z[tokeep]
    ss = ss[tokeep]
    gg = gg[tokeep]


    mpd_data = {
        "N": N, "J": J, "G"=G, 
        "ss": ss, "gg": gg,
        "z": z, "s": s
    }

    return mpd_data
