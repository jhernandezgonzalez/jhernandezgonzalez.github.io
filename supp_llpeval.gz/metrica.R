library(zoo)

lossLLP <- function(real_lps, probs, threshold = 0.5) {
  predLabels <- as.numeric(probs >= threshold)

  BSs <- rowSums(real_lps)
  
  nbags <- length(BSs)
  lBags <- cumsum(BSs)
  iBags <- c(1,lBags[-length(BSs)]+1)

  PredPos <- vector("numeric",length=nbags)
  for (b in 1:nbags){
    PredPos[b] <- sum(predLabels[iBags[b]:lBags[b]])
  }

  res <- 1-sum(abs(real_lps[,2]-PredPos[2])) / sum(real_lps)
  
  return (res)
}


TPsLLP <- function(lps, probs) {
  thrs <- sort(unique(c(0,probs,1)),decreasing = T)
  pesTPs <- vector("numeric",length(thrs))
  ranTPs <- vector("numeric",length(thrs))
  adjTPs <- vector("numeric",length(thrs))
  optTPs <- vector("numeric",length(thrs))
  
  totalPredPos <- vector("numeric",length(thrs))
  
  BSs <- rowSums(lps)
  
  nbags <- length(BSs)
  iBags <- c(1,cumsum(BSs[-length(BSs)])+1)
  lBags <- cumsum(BSs)
  
  recTria <- lps[,2]>mean(lps[,2])
  # recTria <- lps[,2]/BSs>mean(lps[,2]/BSs)
  weigths <- lps[,2]/BSs
  
  for (t in 1:length(thrs)) {
    # PredLabels <- as.numeric(probs >= thrs[t])
    pred <- vector("numeric",length(probs))
    pred[which(probs>=thrs[t])] <- 1
    
    PredPos <- vector("numeric",length=nbags)
    for (b in 1:nbags){
      PredPos[b] <- sum(pred[iBags[b]:lBags[b]])
    }
    
    tpMin <- PredPos+lps[,2]-BSs
    tpMin[tpMin < 0] <- 0
    tpAle <- PredPos * lps[,2] / BSs
    tpMax <- pmin(PredPos,lps[,2])
    tpMed <- sum(  (tpMax*weigths + tpAle*(1-weigths))[recTria] ) / sum( lps[recTria,2] ) * lps[,2]
    # tpMed <- pmin(tpMed,tpMax)
    # tpMed <- pmax(tpMed,tpAle)
    # tpMed <- pmax(tpMed,tpMin)
    
    pesTPs[t]<-sum(tpMin)
    ranTPs[t]<-sum(tpAle)
    adjTPs[t]<-sum(tpMed)
    optTPs[t]<-sum(tpMax)
    
    totalPredPos[t] <- sum(pred)
  }
  
  return( list( thresholds = thrs, pesTPs = pesTPs, ranTPs = ranTPs, adjTPs = adjTPs, optTPs = optTPs, totalPredPos = totalPredPos ) )
}



# interpolationROC <- function(threshold, results){
#   # results: TN, totalRealNeg, TP, totalRealPos
#   rocPoints <- matrix(0,1,3) # threshold, Recall, Precision
#   rocPoints[1,] <- c(threshold[1],1-results[1,1]/results[1,2],results[1,3]/results[1,4])
#   for (i in 2:nrow(results)) { # no-interpolation
#     rocPoints <- rbind(rocPoints, c(threshold[i], 1-results[i,1]/results[i,2], results[i,3]/results[i,4]))
#   }
#   rocPoints[is.nan(rocPoints)] <- 0
#   return (rocPoints)
# }


ROC <- function(realClass,probs,draw=T) {
  realClass = realClass-1
  totalRealPos <- sum(realClass)
  totalRealNeg <- sum(1-realClass)
  
  thrs <- sort(unique(c(0,probs,1)),decreasing = T)
  
  res <- matrix(0,length(thrs),4)
  
  for (t in 1:length(thrs)) {
    pred <- vector("numeric",length(probs))
    pred[which(probs>=thrs[t])] <- 1
    
    TP <- sum(pred*realClass)
    TN <- sum((1-pred)*(1-realClass))
    res[t,]<-c(1- TN/totalRealNeg, TP/totalRealPos)
  }
  
  rocPoints <- cbind(thrs, res)#interpolationROC
  res <- sum(diff(rocPoints[,2])*rollmean(rocPoints[,3],2))

  if (draw) drawCurve(rocPoints, xlab="1-Specificity",ylab="Sensitivity", title=paste("AUROC :",round(res,3)) )

  return( res )
}




ROCLLP <- function(lps,tps,draw=T) {
  totalRealPos <- sum(lps[,2])
  totalRealNeg <- sum(lps[,1])
  resPes <- cbind((tps$totalPredPos-tps$pesTPs)/totalRealNeg, tps$pesTPs/totalRealPos)
  resPes[is.na(resPes)] <- 0
  resRan <- cbind((tps$totalPredPos-tps$ranTPs)/totalRealNeg, tps$ranTPs/totalRealPos)
  resRan[is.na(resRan)] <- 0
  resAdj <- cbind((tps$totalPredPos-tps$adjTPs)/totalRealNeg, tps$adjTPs/totalRealPos)
  resAdj[is.na(resAdj)] <- 0
  resOpt <- cbind((tps$totalPredPos-tps$optTPs)/totalRealNeg, tps$optTPs/totalRealPos)
  resOpt[is.na(resOpt)] <- 0
  
  rocPesPoints <- cbind(tps$thresholds, resPes)
  rocRanPoints <- cbind(tps$thresholds, resRan)
  rocAdjPoints <- cbind(tps$thresholds, resAdj)
  rocOptPoints <- cbind(tps$thresholds, resOpt)
  
  devAdj = sum(diff(rocAdjPoints[,2])*rollmean(rocAdjPoints[,3],2))
  if (draw) {
    drawMultipleCurves(rocPesPoints, rocRanPoints, rocAdjPoints, rocOptPoints, 
                       xlab="1-Specificity",ylab="Sensitivity", title=paste("Adjusted AUROC :", round(devAdj,3) ))
  }
  
  return( list(
    pesAUROC = sum(diff(rocPesPoints[,2])*rollmean(rocPesPoints[,3],2)), 
    ranAUROC = sum(diff(rocRanPoints[,2])*rollmean(rocRanPoints[,3],2)), 
    adjAUROC = devAdj,
    optAUROC = sum(diff(rocOptPoints[,2])*rollmean(rocOptPoints[,3],2)) 
  ) )
}




interpolationPR <- function(threshold, results){
  # results: TP, realPos, predPos
  prPoints <- matrix(0,1,3) # threshold, Recall, Precision
  prPoints[1,] <- c(threshold[1],results[1,1]/results[1,2],results[1,1]/results[1,3])
  for (i in 2:nrow(results)) { # interpolation
    leap <- results[i,1]-results[i-1,1]
    if (leap>=1) {
      factF <- (results[i,3]-results[i,1]-results[i-1,3]+results[i-1,1])/(results[i,1]-results[i-1,1])
      factT <- (threshold[i]-threshold[i-1])/(results[i,1]-results[i-1,1])
      for (l in 1:leap) {
        nTP <- results[i-1,1] + l
        nFP <- (results[i-1,3]-results[i-1,1]) + l * factF
        nT <- threshold[i-1] + l * factT
        prPoints <- rbind(prPoints,c(nT,nTP/results[i-1,2],nTP/(nTP+nFP)))
      }
    }
    prPoints <- rbind(prPoints,c(threshold[i],results[i,1]/results[i,2],results[i,1]/results[i,3]))
  }
  prPoints[is.nan(prPoints)]<-0
  return (prPoints)
}


precisionRecall <- function(realClass,probs,draw=T) {
  realClass = realClass-1
  totalRealPos <- sum(realClass)
  
  thrs <- sort(unique(c(0,probs,1)),decreasing = T)
  
  res <- matrix(0,length(thrs),3)
  
  for (t in 1:length(thrs)) {
    pred <- vector("numeric",length(probs))
    pred[which(probs>=thrs[t])] <- 1
    
    TP <- sum(pred*realClass)
    res[t,]<-c(TP,totalRealPos,sum(pred))
  }
  
  prPoints <- interpolationPR(thrs, res)
  
  res <- sum(diff(prPoints[,2])*rollmean(prPoints[,3],2))
  if (draw) drawCurve(prPoints, title = paste("AUC PR :",round(res,3)) )

  return( res )
}



precisionRecallLLP <- function(lps,tps,draw=T) {
  totalRealPos <- sum(lps[,2])
  resPes <- cbind(tps$pesTPs,totalRealPos, tps$totalPredPos)
  resPes[is.na(resPes)] <- 0
  resRan <- cbind(tps$ranTPs,totalRealPos, tps$totalPredPos)
  resRan[is.na(resRan)] <- 0
  resAdj <- cbind(tps$adjTPs,totalRealPos, tps$totalPredPos)
  resAdj[is.na(resAdj)] <- 0
  resOpt <- cbind(tps$optTPs,totalRealPos, tps$totalPredPos)
  resOpt[is.na(resOpt)] <- 0
  
  prPesPoints <- interpolationPR(tps$thresholds, resPes)
  prRanPoints <- interpolationPR(tps$thresholds, resRan)
  prAdjPoints <- interpolationPR(tps$thresholds, resAdj)
  prOptPoints <- interpolationPR(tps$thresholds, resOpt)

  devAdj <- sum(diff(prAdjPoints[,2])*rollmean(prAdjPoints[,3],2))
  if (draw) {
    drawMultipleCurves(prPesPoints, prRanPoints, prAdjPoints, prOptPoints,
                       title=paste("Adjusted AUC-PR :",round(devAdj,3) ))
  }

  return( list(
    pesAUCPR = sum(diff(prPesPoints[,2])*rollmean(prPesPoints[,3],2)), 
    ranAUCPR = sum(diff(prRanPoints[,2])*rollmean(prRanPoints[,3],2)), 
    adjAUCPR = devAdj, 
    optAUCPR = sum(diff(prOptPoints[,2])*rollmean(prOptPoints[,3],2)) 
  ) )
}


accuracyLLP <- function(lps, tps, threshold=0.5) {
  auxThr <- which(tps$thresholds>0.5)
  auxThr <- auxThr[length(auxThr)]
  
  ninsts = sum(lps)
  
  pesTN = sum(lps[,1]) - tps$totalPredPos[auxThr] + tps$pesTPs[auxThr]
  ranTN = sum(lps[,1]) - tps$totalPredPos[auxThr] + tps$ranTPs[auxThr]
  adjTN = sum(lps[,1]) - tps$totalPredPos[auxThr] + tps$adjTPs[auxThr]
  optTN = sum(lps[,1]) - tps$totalPredPos[auxThr] + tps$optTPs[auxThr]
  
  return( list(
    pesAcc = (tps$pesTPs[auxThr]+pesTN)/ninsts, 
    ranAcc = (tps$ranTPs[auxThr]+ranTN)/ninsts, 
    adjAcc = (tps$adjTPs[auxThr]+adjTN)/ninsts, 
    optAcc = (tps$optTPs[auxThr]+optTN)/ninsts
  ) )
}

accuracy <- function(realClass, probs, threshold=0.5) {
  realClass = realClass-1
  
  predLabels <- as.numeric(probs >= threshold)
  
  ninsts = length(realClass)
  
  return( sum(diag(table(as.factor(realClass), as.factor(predLabels)))) / ninsts )
}


precisionLLP <- function(lps, tps, threshold=0.5) {
  auxThr <- which(tps$thresholds>0.5)
  auxThr <- auxThr[length(auxThr)]
  
  pesPrec = tps$pesTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(pesPrec)) pesPrec <- 0
  ranPrec = tps$ranTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(ranPrec)) ranPrec <- 0
  adjPrec = tps$adjTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(adjPrec)) adjPrec <- 0
  optPrec = tps$optTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(optPrec)) optPrec <- 0
  
  return( list( pesPrec = pesPrec, ranPrec = ranPrec, adjPrec = adjPrec, optPrec = optPrec ) )
}

precision <- function(realClass, probs, threshold=0.5) {
  realClass = realClass-1
  predLabels <- as.numeric(probs >= threshold)
  
  prec <- sum(realClass*predLabels)/sum(predLabels)
  if (is.na(prec)) prec <- 0
  
  return( prec )
}


recallLLP <- function(lps, tps, threshold=0.5) {
  totalRealPos <- sum(lps[,2])
  auxThr <- which(tps$thresholds>0.5)
  auxThr <- auxThr[length(auxThr)]

  pesRec = tps$pesTPs[auxThr] / totalRealPos
  if (is.na(pesRec)) pesRec <- 0
  ranRec = tps$ranTPs[auxThr] / totalRealPos
  if (is.na(ranRec)) ranRec <- 0
  adjRec = tps$adjTPs[auxThr] / totalRealPos
  if (is.na(adjRec)) adjRec <- 0
  optRec = tps$optTPs[auxThr] / totalRealPos
  if (is.na(optRec)) optRec <- 0
  
  return( list( pesRec = pesRec, ranRec = ranRec, adjRec = adjRec, optRec = optRec ) )
}

recall <- function(realClass, probs, threshold=0.5) {
  realClass = realClass-1
  predLabels <- as.numeric(probs >= threshold)
  
  rec <- sum(realClass*predLabels)/sum(realClass)
  if (is.na(rec)) rec <- 0
  
  return( rec )
}





FmeasureLLP <- function(lps, tps, threshold=0.5, beta = 1) {
  totalRealPos <- sum(lps[,2])
  auxThr <- which(tps$thresholds>0.5)
  auxThr <- auxThr[length(auxThr)]
  
  pesPrec = tps$pesTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(pesPrec)) pesPrec <- 0
  ranPrec = tps$ranTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(ranPrec)) ranPrec <- 0
  adjPrec = tps$adjTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(adjPrec)) adjPrec <- 0
  optPrec = tps$optTPs[auxThr]/tps$totalPredPos[auxThr]
  if (is.na(optPrec)) optPrec <- 0
  
  pesRec = tps$pesTPs[auxThr] / totalRealPos
  if (is.na(pesRec)) pesRec <- 0
  ranRec = tps$ranTPs[auxThr] / totalRealPos
  if (is.na(ranRec)) ranRec <- 0
  adjRec = tps$adjTPs[auxThr] / totalRealPos
  if (is.na(adjRec)) adjRec <- 0
  optRec = tps$optTPs[auxThr] / totalRealPos
  if (is.na(optRec)) optRec <- 0
  
  pesF = (1+beta^2) * pesPrec * pesRec / (beta^2*pesPrec + pesRec)
  if (is.na(pesF)) pesF <- 0
  ranF = (1+beta^2) * ranPrec * ranRec / (beta^2*ranPrec + ranRec)
  if (is.na(ranF)) ranF <- 0
  adjF = (1+beta^2) * adjPrec * adjRec / (beta^2*adjPrec + adjRec)
  if (is.na(adjF)) adjF <- 0
  optF = (1+beta^2) * optPrec * optRec / (beta^2*optPrec + optRec)
  if (is.na(optF)) optF <- 0
  return( list( 
    pesF = pesF, 
    ranF = ranF, 
    adjF = adjF, 
    optF = optF
    ) )
}


Fmeasure <- function(realClass, probs, threshold=0.5, beta = 1) {
  realClass = realClass-1
  predLabels <- as.numeric(probs >= threshold)
  
  TP <- sum(realClass*predLabels)

  prec <- TP/sum(predLabels)
  if (is.na(prec)) prec <- 0
  rec <- TP/sum(realClass)
  if (is.na(rec)) rec <- 0
  
  if ((rec == 0) & (prec == 0)) return (0)

  return( (1+beta^2) * prec * rec / (beta^2*prec + rec) )
}








drawMultipleCurves <- function(prMinPoints, prAlePoints, prMedPoints, prMaxPoints, xlab = "Recall", ylab = "Precision", title = "PR Curve") {
  rbPal <- colorRampPalette(c("green","red"))
  cool <- rbPal(nrow(prMinPoints))[as.numeric(cut(prMinPoints[,1],breaks = nrow(prMinPoints)))]
  
  par(fig=c(0,0.9,0,1))
  plot(prMinPoints[1,2], prMinPoints[1,3], pch=".", col = cool[1],
       xlab=xlab, ylab=ylab, xlim = c(0,1), ylim=c(0,1))
  for (i in 2:nrow(prMinPoints)) {
    lines(prMinPoints[(i-1):i,2], prMinPoints[(i-1):i,3], col=cool[i])
  }
  polygon(c(prMaxPoints[,2],rev(prMinPoints[,2])), c(prMaxPoints[,3],rev(prMinPoints[,3])),col='gray90',border=NA)
  
  cool <- rbPal(nrow(prAlePoints))[as.numeric(cut(prAlePoints[,1],breaks = nrow(prAlePoints)))]
  
  par(fig=c(0,0.9,0,1), new=TRUE)
  plot(prAlePoints[1,2], prAlePoints[1,3], pch=".", col=cool[1],
       xlab="", ylab="", xlim=c(0,1), ylim=c(0,1), axes = F)
  for (i in 2:nrow(prAlePoints)) {
    lines(prAlePoints[(i-1):i,2],prAlePoints[(i-1):i,3],col = cool[i])
  }
  
  cool <- rbPal(nrow(prMedPoints))[as.numeric(cut(prMedPoints[,1],breaks = nrow(prMedPoints)))]
  
  par(fig=c(0,0.9,0,1), new=TRUE)
  plot(prMedPoints[1,2], prMedPoints[1,3], pch=".", col=cool[1],
       xlab="", ylab="", xlim=c(0,1), ylim=c(0,1), axes = F)
  for (i in 2:nrow(prMedPoints)) {
    lines(prMedPoints[(i-1):i,2],prMedPoints[(i-1):i,3],col = cool[i])
  }
  
  cool <- rbPal(nrow(prMaxPoints))[as.numeric(cut(prMaxPoints[,1],breaks = nrow(prMaxPoints)))]
  
  par(fig=c(0,0.9,0,1), new=TRUE)
  plot(prMaxPoints[1,2], prMaxPoints[1,3], pch=".", col=cool[1],
       xlab="", ylab="", xlim=c(0,1), ylim=c(0,1), axes = F)
  for (i in 2:nrow(prMaxPoints)) {
    lines(prMaxPoints[(i-1):i,2],prMaxPoints[(i-1):i,3],col = cool[i])
  }
  
  par(fig=c(0.6,1,0,1), new=TRUE)
  legend_image <- as.raster(matrix(cool, ncol=1))
  plot(c(0,2),c(0,1),type = 'n', axes = F,xlab = '', ylab = '')
  text(x=1.5, y = seq(0,1,l=5), cex=0.6, srt=270, labels=seq(0,1,l=5))
  rasterImage(legend_image, 0, 0, 1,1)
  
  mtext(title, side=3, outer=TRUE, line=-3)
}

drawCurve <- function(prPoints, xlab = "Recall", ylab = "Precision", title = "PR Curve") {
  rbPal <- colorRampPalette(c("green","red"))
  cool <- rbPal(nrow(prPoints))[as.numeric(cut(prPoints[,1],breaks = nrow(prPoints)))]
  
  par(fig=c(0,0.9,0,1))
  plot(prPoints[1,2], prPoints[1,3], pch=".", col = cool[1],
       xlab=xlab, ylab=ylab, xlim = c(0,1), ylim=c(0,1))
  for (i in 2:nrow(prPoints)) {
    lines(prPoints[(i-1):i,2], prPoints[(i-1):i,3], col=cool[i])
  }
  
  par(fig=c(0.6,1,0,1), new=TRUE)
  legend_image <- as.raster(matrix(cool, ncol=1))
  plot(c(0,2),c(0,1),type = 'n', axes = F,xlab = '', ylab = '')
  text(x=1.5, y = seq(0,1,l=5), cex=0.6, srt=270, labels=seq(0,1,l=5))
  rasterImage(legend_image, 0, 0, 1,1)
  
  mtext(title, side=3, outer=TRUE, line=-3)
}


