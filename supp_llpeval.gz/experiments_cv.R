source("181210/_functions_aux.R")
source("181210/metrica.R")
source("181210/cv_strategies.R")
source("181210/generate_data_kdb.R")
source("181210/knn.R")
library(gtools)
library(stringr)
library(primes)



generateBagSizes <- function(n, bagsizes, iCenterBS, iStdBS) {
  stdev <- 8 / 2^iStdBS
  alpha <- exp(-((1:length(bagsizes))-iCenterBS)^2/stdev^2)
  alpha <- 45*alpha / sum(alpha)
  
  probsBSs <- rdirichlet(1, alpha)
  
  BSs <- sample(bagsizes, round(n/bagsizes[1]), replace = T, prob = probsBSs)
  sumas <- cumsum(BSs)
  aux <- which(sumas >= n)[1]
  BSs <- BSs[1:aux]
  BSs[aux] <- BSs[aux] - (sumas[aux] - n)
  
  return(BSs)
}



obtainFolds <- function(real_lps, technique=1, kCV=3) {
  folds <- list()
  if (technique==1) {
    folds <- createLeaveOneBagOut(real_lps)
  } else if (technique==2) {
    folds <- createDeterministicKfoldCV(real_lps, kCV)
  } else if (technique==3) {
    folds <- createUniformRandomKfoldCV(real_lps, kCV)
  } else if (technique==4) {
    folds <- createSizedRandomKfoldCV(real_lps, kCV)
  } else if (technique==5) {
    folds <- createRandomStratifiedKfoldCV(real_lps, kCV)
  }
  return(folds)
}

cvexecution <- function(SData, iclass, n, real_lps, bagstoinds, folds, fileConn){
  dr <- F
  thr <- 0.5
  
  nFolds <- length(folds)
  resultsNB <- matrix(0,nrow=7,ncol=0)
  resultsNN <- matrix(0,nrow=7,ncol=0)
  for (f in 1:nFolds){
    partition <- getPartition(f, folds)
    
    # dataPARTITION
    trainPartition <- unlist(bagstoinds[partition$trainBags])
    trainData <- SData[trainPartition,,drop=F]
    trainLps <- real_lps[partition$trainBags,,drop=F]
    valPartition <- unlist(bagstoinds[partition$validationBags])
    valData <- SData[valPartition,,drop=F]
    valLps <- real_lps[partition$validationBags,,drop=F]
    
    # Aprender clasificador 1
    nbmodel <- naiveBayes(C ~ ., data = trainData)
    classProbs <- predict(nbmodel, valData, type="raw")+0.002
    classProbs <- classProbs/rowSums(classProbs)
    
    # calcular_errores
    tps <- TPsLLP(valLps, classProbs[,2])
    resultsNB <- cbind(resultsNB, 
                       c(precisionRecallLLP(valLps, tps, draw=dr)$adjAUCPR,
                         ROCLLP(valLps, tps, draw=dr)$adjAUROC,
                         accuracyLLP(valLps, tps, threshold=thr)$adjAcc,
                         lossLLP(valLps, classProbs[,2]),
                         precisionRecall(as.numeric(valData[,iclass]), classProbs[,2], draw=dr),
                         ROC(as.numeric(valData[,iclass]), classProbs[,2], draw=dr),
                         accuracy(as.numeric(valData[,iclass]), classProbs[,2], threshold=thr)
                       ))
    
    # Aprender clasificador 2
    knnmodel <- knn.dist(SData[,-ncol(SData)]) 
    classProbs <- t(knn.probability(trainPartition, valPartition, factor(SData[,ncol(SData)]), knnmodel, k = 1)) + 0.002
    classProbs <- classProbs/rowSums(classProbs)
    
    # calcular_errores
    tps <- TPsLLP(valLps, classProbs[,2])
    resultsNN <- cbind(resultsNN, 
                       c(precisionRecallLLP(valLps, tps, draw=dr)$adjAUCPR,
                         ROCLLP(valLps, tps, draw=dr)$adjAUROC,
                         accuracyLLP(valLps, tps, threshold=thr)$adjAcc,
                         lossLLP(valLps, classProbs[,2]),
                         precisionRecall(as.numeric(valData[,iclass]), classProbs[,2], draw=dr),
                         ROC(as.numeric(valData[,iclass]), classProbs[,2], draw=dr),
                         accuracy(as.numeric(valData[,iclass]), classProbs[,2], threshold=thr)
                       ))
    
  }
  writeLines(apply(resultsNB,1,function(y)paste(y,collapse=";")), fileConn)
  writeLines(apply(resultsNN,1,function(y)paste(y,collapse=";")), fileConn)
}
cvexecutionLOBO <- function(SData, iclass, n, real_lps, bagstoinds, folds, fileConn){
  dr <- F
  thr <- 0.5
  
  nFolds <- length(folds)
  resultsNB <- matrix(0,nrow=2,ncol=0)
  resultsNN <- matrix(0,nrow=2,ncol=0)
  classProbsNB <- matrix(0,nrow=0,ncol=2)
  classProbsNN <- matrix(0,nrow=0,ncol=2)
  for (f in 1:nFolds){
    partition <- getPartition(f, folds)
    
    # dataPARTITION
    trainPartition <- unlist(bagstoinds[partition$trainBags])
    trainData <- SData[trainPartition,,drop=F]
    trainLps <- real_lps[partition$trainBags,,drop=F]
    valPartition <- unlist(bagstoinds[partition$validationBags])
    valData <- SData[valPartition,,drop=F]
    valLps <- real_lps[partition$validationBags,,drop=F]
    
    # Aprender clasificador 1
    nbmodel <- naiveBayes(C ~ ., data = trainData)
    classProbs <- predict(nbmodel, valData, type="raw")+0.002
    classProbs <- classProbs/rowSums(classProbs)
    classProbsNB <- rbind(classProbsNB, classProbs)
    
    # calcular_errores
    tps <- TPsLLP(valLps, classProbs[,2])
    resultsNB <- cbind(resultsNB, 
                       c(1 - abs(valLps[1,2]- sum(as.numeric(classProbs[,2] >= thr))) / sum(valLps),
                         accuracy(as.numeric(valData[,iclass]), classProbs[,2], threshold=thr)
                       ))
    
    # Aprender clasificador 2
    knnmodel <- knn.dist(SData[,-ncol(SData)]) 
    classProbs <- t(knn.probability(trainPartition, valPartition, factor(SData[,ncol(SData)]), knnmodel, k = 1)) + 0.002
    classProbs <- classProbs/rowSums(classProbs)
    classProbsNN <- rbind(classProbsNN, classProbs)
    
    
    # calcular_errores
    tps <- TPsLLP(valLps, classProbs[,2])
    resultsNN <- cbind(resultsNN, 
                       c(1 - abs(valLps[1,2]- sum(as.numeric(classProbs[,2] >= thr))) / sum(valLps),
                         accuracy(as.numeric(valData[,iclass]), classProbs[,2], threshold=thr)
                       ))
  }
  writeLines(apply(resultsNB,1,function(y)paste(y,collapse=";")), fileConn)
  writeLines(apply(resultsNN,1,function(y)paste(y,collapse=";")), fileConn)
  
  # calcular_errores
  tps <- TPsLLP(real_lps, classProbsNB[,2])
  resultsGlNB <- matrix(c(precisionRecallLLP(real_lps, tps, draw=dr)$adjAUCPR,
                       ROCLLP(real_lps, tps, draw=dr)$adjAUROC,
                       accuracyLLP(real_lps, tps, threshold=thr)$adjAcc,
                       lossLLP(real_lps, classProbsNB[,2]),
                       precisionRecall(as.numeric(SData[,iclass]), classProbsNB[,2], draw=dr),
                       ROC(as.numeric(SData[,iclass]), classProbsNB[,2], draw=dr),
                       accuracy(as.numeric(SData[,iclass]), classProbsNB[,2], threshold=thr)
                     ),ncol=1)
  
  # calcular_errores
  tps <- TPsLLP(real_lps, classProbsNN[,2])
  resultsGlNN <- matrix(c(precisionRecallLLP(real_lps, tps, draw=dr)$adjAUCPR,
                       ROCLLP(real_lps, tps, draw=dr)$adjAUROC,
                       accuracyLLP(real_lps, tps, threshold=thr)$adjAcc,
                       lossLLP(real_lps, classProbsNN[,2]),
                       precisionRecall(as.numeric(SData[,iclass]), classProbsNN[,2], draw=dr),
                       ROC(as.numeric(SData[,iclass]), classProbsNN[,2], draw=dr),
                       accuracy(as.numeric(SData[,iclass]), classProbsNN[,2], threshold=thr)
                       ),ncol=1)

  writeLines(apply(resultsGlNB,1,function(y)paste(y,collapse=";")), fileConn)
  writeLines(apply(resultsGlNN,1,function(y)paste(y,collapse=";")), fileConn)
}


experimento <- function(SData, iclass, n, real_lps, bagstoinds, kCVs, repCV, nombre){
  fileConn <- file(nombre,"w")
  
  cat("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\btech:",1,"kCV:",str_pad(0, 2, pad = "0"))
  folds <- obtainFolds(real_lps, 1, 0)
  cvexecutionLOBO(SData, iclass, n, real_lps, bagstoinds, folds, fileConn)

  for (kcv in kCVs) {
    cat("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\btech:",2,"kCV:",str_pad(kcv, 2, pad = "0"))
    folds <- obtainFolds(real_lps, 2, kcv)
    cvexecution(SData, iclass, n, real_lps, bagstoinds, folds, fileConn)
  }
  
  for (tech in 5:5){
    for (kcv in kCVs) {
      for (rep in 1:repCV){
        cat("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\btech:",tech,"kCV:",str_pad(kcv, 2, pad = "0"))
        folds <- obtainFolds(real_lps, tech,kcv)
        cvexecution(SData, iclass, n, real_lps, bagstoinds, folds, fileConn)
      }
    }
  }
  
  close(fileConn)
}

################################# PARAMETERS #################################

bagsizes <- c(5,10,15,20,25,30,35,40,45)

KDBS <- seq(0,4,2)          # K de los modelos generadores KDB
# Kdb <- 2

CPRVs <- c(3,4)             # cardinalidad de las variables predictoras
# cardPrVars <- 3

PSSs <- c(0.01,0.025,0.05)  # proporcion del sample size
# pSS <- 0.01#

CBSs <- seq(2,8,3)          # cual es el tamaño de bag mas frecuente
# iCenterBS <- 5

SBSs <- seq(0,4,2) #0:4                 # variacion del tamaño de las bags
# iStdBS <- 1 #

# KDBS <- c(2)          # K de los modelos generadores KDB
# # Kdb <- 2 
# 
# CPRVs <- c(3)             # cardinalidad de las variables predictoras
# # cardPrVars <- 3 
# 
# PSSs <- c(0.01)  # proporcion del sample size
# # pSS <- 0.01# 
# 
# CBSs <- c(1)          # cual es el tamaño de bag mas frecuente
# # iCenterBS <- 5 
# 
# SBSs <- 1                 # variacion del tamaño de las bags
# # iStdBS <- 1 #

kCVs <- c(3,5,10)           # cuales son los K de KFold que probaremos
repCV <- 10

nrep1 <- nrep2 <- 10
nrep3 <- nrep4 <- 5


PRIMOS <- generate_primes(min=10, max=10000)[1:(nrep1*length(KDBS)*length(CPRVs))]


################################# EXECUTION #################################

for (ikdb in 1:1) {
  Kdb <- KDBS[ikdb]
  for (icprv in 1:length(CPRVs)) {
    cardPrVars <- CPRVs[icprv]
    
    sampleSize <- cardPrVars^10*2
    for (r1 in 1:nrep1) {
      iprimo = ((ikdb-1)*length(CPRVs)*nrep1) + ((icprv-1)*nrep1)+ r1

      set.seed(PRIMOS[iprimo])
      kdbmodel <- kdb_generator(Kdb, cardpredvars = cardPrVars)

      for (pSS in PSSs){
        for (r2 in 1:nrep2){
          n <- round(sampleSize*pSS)
          dtst <- sample_kdb(kdbmodel, n)
          
          for (iCenterBS in CBSs){
            for (iStdBS in SBSs){
              for (r3 in 1:nrep3){
                BSs <- generateBagSizes(n, bagsizes, iCenterBS, iStdBS)
                lBags <- cumsum(BSs)
                iBags <- c(1,lBags[-length(BSs)]+1)
                bagstoinds <- list()
                for (aux in 1:length(BSs)) bagstoinds[[aux]] <- iBags[aux]:lBags[aux]
                
                for (r4 in 1:nrep4){
                  cat("KDB:", Kdb,
                      "; CPRV:", cardPrVars,
                      "; R1.:", r1,
                      "; PSS:", pSS, 
                      "; R2.:", r2,
                      "; CBS:", iCenterBS, 
                      "; SBS:", iStdBS, #str_pad(bs, 2, pad = "0"), 
                      "; R3.:", r3,
                      "; R4.:", r4,"                        ")
                  
                  SData <- dtst[sample(1:n,n),]
                    
                  real_lps <- obtain_lps_given_bss(SData[,kdbmodel$iclass], BSs)
                  nombre = paste("181210/results_cv/",
                                 "KDB_",Kdb,"_card_",cardPrVars,"_r1_",r1,
                                 "_SS_",pSS,"_r2_",r2,
                                 "_BSc_",bagsizes[iCenterBS],"_BSstd_", iStdBS,"_r3_",r3,"_r4_",r4,
                                 ".resout", sep="")
                  
                  
                  start_time <- Sys.time()
                  experimento(SData, kdbmodel$iclass, n, real_lps, bagstoinds, kCVs, repCV, nombre)
                  end_time <- Sys.time()
                  cat(" - Tiempo: ", end_time - start_time, "\n")
                }
              }
            }
          }
        }
      }
    }
  }
}


